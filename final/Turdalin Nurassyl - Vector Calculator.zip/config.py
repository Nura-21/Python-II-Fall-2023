config = {
    'window': {
        # Mode: system, light, dark
        'mode': 'dark',
        # Themes: blue, dark-blue, green
        'theme': 'dark-blue',
        'title': 'Vector calculator',
        'size': '400x700',
        'scale': 1.2
    }
}
