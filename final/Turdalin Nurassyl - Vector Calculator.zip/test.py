from main import Window

test_app = Window()
test_app.test()
